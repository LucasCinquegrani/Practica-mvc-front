package desafio;

import desafio.menu.MenuController;

public class App {

    public static void main(String[] args) {

        MenuController menuController = new MenuController();
        menuController.execute();
    }
}
