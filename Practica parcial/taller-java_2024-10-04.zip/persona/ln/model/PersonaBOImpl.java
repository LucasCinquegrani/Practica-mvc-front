package persona.ln.model;

import java.util.List;

import persona.ln.domain.Persona;

public interface PersonaBOImpl {

    List<Persona> getPersonas();

}