package persona.ad.data_access;

import java.util.List;

import persona.ln.domain.Persona;

public interface PersonaADImpl {

    public List<Persona> findByAll();

}
